package Lesson5.prob2;

public interface Shape {
	double computeArea();
}
