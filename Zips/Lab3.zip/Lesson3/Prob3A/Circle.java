package Lesson3.Prob3A;

public class Circle extends Cylinder{
	
	public Circle(double radius) {
		super(radius);
	}
	
	public String toString() {
		return String.format("Area of circle is %.2f.", computeArea());
	}
}