package Lesson3.Prob3A;

public class Main {

	public static void main(String[] args) {
		Circle ci1 = new Circle(3);
		Cylinder cy1 = new Cylinder(3, 6);
		
		System.out.println(ci1);
		System.out.println(cy1);
	}
}