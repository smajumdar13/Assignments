package Lesson3.Prob4;

abstract class Property {
	abstract double computeRent();
}