package Lesson3.Prob4;

public class House extends Property {
	private double lotSize;
	private Address address;
	
	House(double size){
		lotSize = size;
	}
	
	House(double size, Address add) {
		address = add;
		lotSize = size;
	}
	
	public double getLotSize() {
		return lotSize;
	}
	
	public double computeRent() {
		return 0.1*lotSize;
	}
}