package Lesson10.Prob4;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
