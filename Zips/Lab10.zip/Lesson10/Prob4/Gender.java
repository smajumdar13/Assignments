package Lesson10.Prob4;

public enum Gender {
	M, F
}
