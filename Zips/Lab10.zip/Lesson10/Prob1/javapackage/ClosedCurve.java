package Lesson10.Prob1.javapackage;

import Lesson10.Prob1.bugreporter.BugReport;

@BugReport(assignedTo="Tom Jones", severity=1, reportedBy="Sam")
public interface ClosedCurve {
	public double computePerimeter();
}
