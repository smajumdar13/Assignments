package Lesson4.ProbE;

public abstract class Account {
	public abstract String getAccountID();
	public abstract double getBalance();
	public abstract double computeUpdatedBalance(); 
}
