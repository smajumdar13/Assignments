package Lesson9.Part10.a;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
